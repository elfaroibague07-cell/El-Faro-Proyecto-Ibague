import { defineStore } from 'pinia'

import type { Product } from '../types/product'
import type { ProductForm } from '../composables/useProductModal'

import ProductService from '../services/product.service'
import StorageService from '../services/storage.service'

export const useProductStore = defineStore('products', {

  /* =========================================
     STATE
  ========================================= */

  state: () => ({

    products: [] as Product[],

    selectedProduct: null as Product | null,

    loading: false

  }),


  /* =========================================
     GETTERS
  ========================================= */

  getters: {

    featuredProducts: state => {

      return state.products.filter(
        product =>
          product.featured &&
          product.active
      )

    },


    activeProducts: state => {

      return state.products.filter(
        product =>
          product.active
      )

    },


    productById: state => {

      return (id: string) => {

        return (
          state.products.find(
            product =>
              product.id === id
          ) ?? null
        )

      }

    },


    productBySlug: state => {

      return (slug: string) => {

        return (
          state.products.find(
            product =>
              product.slug === slug
          ) ?? null
        )

      }

    }

  },


  /* =========================================
     ACTIONS
  ========================================= */

  actions: {

    /* =======================================
       CARGAR PRODUCTOS
    ======================================= */

    async loadProducts(): Promise<void> {

      this.loading = true

      try {

        this.products =
          await ProductService.getProducts()

      }

      catch (error) {

        console.error(
          'Error cargando productos:',
          error
        )

        this.products = []

        throw error

      }

      finally {

        this.loading = false

      }

    },


    /* =======================================
       OBTENER PRODUCTO POR ID
    ======================================= */

    async getProduct(
      id: string
    ): Promise<Product | null> {

      this.selectedProduct = null

      try {

        const product =
          await ProductService.getProductById(id)

        this.selectedProduct =
          product

        return product

      }

      catch (error) {

        console.error(
          'Error obteniendo producto:',
          error
        )

        throw error

      }

    },


    /* =======================================
       OBTENER PRODUCTO POR SLUG
    ======================================= */

    async getProductBySlug(
      slug: string
    ): Promise<Product | null> {

      this.selectedProduct = null

      try {

        const product =
          await ProductService.getProductBySlug(
            slug
          )

        this.selectedProduct =
          product

        return product

      }

      catch (error) {

        console.error(
          'Error obteniendo producto por slug:',
          error
        )

        throw error

      }

    },


    /* =======================================
       CREAR PRODUCTO
    ======================================= */

    async createProduct(
      product: ProductForm
    ): Promise<Product> {

      this.loading = true

      try {

        const created =
          await ProductService.createProduct(
            product
          )

        this.products.unshift(
          created
        )

        return created

      }

      catch (error) {

        console.error(
          'Error creando producto:',
          error
        )

        throw error

      }

      finally {

        this.loading = false

      }

    },


    /* =======================================
       ACTUALIZAR PRODUCTO
    ======================================= */

    async updateProduct(
      id: string,
      product: Partial<ProductForm>
    ): Promise<Product> {

      this.loading = true

      try {

        const updated =
          await ProductService.updateProduct(
            id,
            product
          )

        const index =
          this.products.findIndex(
            item =>
              item.id === id
          )

        if (index !== -1) {

          this.products.splice(
            index,
            1,
            updated
          )

        }

        if (
          this.selectedProduct?.id === id
        ) {

          this.selectedProduct =
            updated

        }

        return updated

      }

      catch (error) {

        console.error(
          'Error actualizando producto:',
          error
        )

        throw error

      }

      finally {

        this.loading = false

      }

    },


    /* =======================================
       ELIMINAR PRODUCTO
    ======================================= */

    async deleteProduct(
      id: string,
      imageUrl?: string
    ): Promise<void> {

      this.loading = true

      try {

        /*
         * Primero eliminamos el producto
         * de Supabase.
         */

        await ProductService.deleteProduct(id)

        /*
         * Actualizamos el estado local.
         */

        this.products =
          this.products.filter(
            product =>
              product.id !== id
          )

        /*
         * Limpiamos seleccionado.
         */

        if (
          this.selectedProduct?.id === id
        ) {

          this.selectedProduct = null

        }

        /*
         * La imagen está en Storage.
         * Si falla, no revertimos el borrado
         * del producto.
         */

        if (imageUrl) {

          try {

            await StorageService.deleteProductImage(
              imageUrl
            )

          }

          catch (storageError) {

            console.error(
              'Producto eliminado, pero no fue posible eliminar su imagen:',
              storageError
            )

          }

        }

      }

      catch (error) {

        console.error(
          'Error eliminando producto:',
          error
        )

        throw error

      }

      finally {

        this.loading = false

      }

    },


    /* =======================================
       LIMPIAR PRODUCTO SELECCIONADO
    ======================================= */

    clearSelectedProduct(): void {

      this.selectedProduct = null

    },


    /* =======================================
       LIMPIAR STORE
    ======================================= */

    clearStore(): void {

      this.products = []

      this.selectedProduct = null

    }

  }

})